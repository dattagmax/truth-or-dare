# Truth or Dare v2
Includes Classic and Spicy 18+ modes, categories, random Truth/Dare, timer, scoring, leaderboard, custom cards, and 100+ built-in prompts.
Open in Android Studio and use Build > Build APK(s).
APK output: app/build/outputs/apk/debug/app-debug.apk


Launcher icon: adaptive Android icon added in v5 for Android 8+ devices, with legacy fallbacks for older Android versions.
